using Microsoft.AspNetCore.Identity;

namespace FireAndIce.Models
{
    public class ApplicationUser : IdentityUser
    {
        // Допълнителни полета, ако са необходими (засега няма според заданието)
    }
}
