using System;
using System.ComponentModel.DataAnnotations;

namespace FireAndIce.Models
{
    public class ServiceRequest
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Името на заявката е задължително.")]
        [Display(Name = "Име на заявка")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Описанието на проблема е задължително.")]
        [Display(Name = "Описание на проблема")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Адресът е задължителен.")]
        [Display(Name = "Адрес")]
        public string Address { get; set; }

        [Display(Name = "Изображение")]
        public string? ImageUrl { get; set; }

        [Display(Name = "Статус")]
        public string Status { get; set; } = "изчакваща"; // изчакваща, очаква посещение, в прогрес, приключена

        [Display(Name = "Дата на посещение")]
        [DataType(DataType.Date)]
        public DateTime? VisitDate { get; set; }

        public string? CustomerId { get; set; }
        public ApplicationUser? Customer { get; set; }

        public string? TechnicianId { get; set; }
        public ApplicationUser? Technician { get; set; }
    }
}
