using FireAndIce.Data;
using FireAndIce.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace FireAndIce.Controllers
{
    [Authorize]
    public class ServiceRequestsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IWebHostEnvironment _env;

        public ServiceRequestsController(ApplicationDbContext context, UserManager<ApplicationUser> userManager, IWebHostEnvironment env)
        {
            _context = context;
            _userManager = userManager;
            _env = env;
        }

        // ===========================
        //  CUSTOMER ACTIONS
        // ===========================

        /// <summary>
        /// Клиентът вижда всички свои заявки, с опция за филтриране по статус.
        /// </summary>
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> MyRequests(string? statusFilter)
        {
            var userId = _userManager.GetUserId(User);
            var query = _context.ServiceRequests
                .Include(sr => sr.Technician)
                .Where(sr => sr.CustomerId == userId);

            if (!string.IsNullOrEmpty(statusFilter))
            {
                query = query.Where(sr => sr.Status == statusFilter);
            }

            ViewBag.StatusFilter = statusFilter;
            ViewBag.Statuses = new List<string> { "изчакваща", "очаква посещение", "в прогрес", "приключена" };
            return View(await query.ToListAsync());
        }

        /// <summary>
        /// Форма за създаване на нова заявка от клиент.
        /// </summary>
        [Authorize(Roles = "Customer")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> Create(ServiceRequest model, IFormFile? imageFile)
        {
            if (ModelState.IsValid)
            {
                model.CustomerId = _userManager.GetUserId(User);
                model.Status = "изчакваща";
                model.VisitDate = null;
                model.TechnicianId = null;

                if (imageFile != null && imageFile.Length > 0)
                {
                    var uploads = Path.Combine(_env.WebRootPath, "uploads");
                    Directory.CreateDirectory(uploads);
                    var fileName = Guid.NewGuid() + Path.GetExtension(imageFile.FileName);
                    var filePath = Path.Combine(uploads, fileName);
                    using var stream = new FileStream(filePath, FileMode.Create);
                    await imageFile.CopyToAsync(stream);
                    model.ImageUrl = "/uploads/" + fileName;
                }

                _context.ServiceRequests.Add(model);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(MyRequests));
            }
            return View(model);
        }

        /// <summary>
        /// Редактиране на заявка от клиент (само заглавие, описание, адрес, изображение).
        /// </summary>
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> Edit(int id)
        {
            var userId = _userManager.GetUserId(User);
            var request = await _context.ServiceRequests.FirstOrDefaultAsync(sr => sr.Id == id && sr.CustomerId == userId);
            if (request == null) return NotFound();
            return View(request);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> Edit(int id, ServiceRequest model, IFormFile? imageFile)
        {
            var userId = _userManager.GetUserId(User);
            var existing = await _context.ServiceRequests.FirstOrDefaultAsync(sr => sr.Id == id && sr.CustomerId == userId);
            if (existing == null) return NotFound();

            if (ModelState.IsValid)
            {
                existing.Title = model.Title;
                existing.Description = model.Description;
                existing.Address = model.Address;

                if (imageFile != null && imageFile.Length > 0)
                {
                    var uploads = Path.Combine(_env.WebRootPath, "uploads");
                    Directory.CreateDirectory(uploads);
                    var fileName = Guid.NewGuid() + Path.GetExtension(imageFile.FileName);
                    var filePath = Path.Combine(uploads, fileName);
                    using var stream = new FileStream(filePath, FileMode.Create);
                    await imageFile.CopyToAsync(stream);
                    existing.ImageUrl = "/uploads/" + fileName;
                }

                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(MyRequests));
            }
            return View(model);
        }

        /// <summary>
        /// Изтриване на заявка от клиент — само ако е „изчакваща".
        /// </summary>
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> Delete(int id)
        {
            var userId = _userManager.GetUserId(User);
            var request = await _context.ServiceRequests.FirstOrDefaultAsync(sr => sr.Id == id && sr.CustomerId == userId);
            if (request == null) return NotFound();
            if (request.Status != "изчакваща")
            {
                TempData["Error"] = "Можете да изтривате само заявки със статус \"изчакваща\".";
                return RedirectToAction(nameof(MyRequests));
            }
            return View(request);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var userId = _userManager.GetUserId(User);
            var request = await _context.ServiceRequests.FirstOrDefaultAsync(sr => sr.Id == id && sr.CustomerId == userId);
            if (request == null) return NotFound();
            if (request.Status != "изчакваща")
            {
                TempData["Error"] = "Можете да изтривате само заявки със статус \"изчакваща\"."
;
                return RedirectToAction(nameof(MyRequests));
            }
            _context.ServiceRequests.Remove(request);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(MyRequests));
        }

        // ===========================
        //  TECHNICIAN ACTIONS
        // ===========================

        /// <summary>
        /// Техникът вижда всички зачислени му заявки.
        /// </summary>
        [Authorize(Roles = "Tech")]
        public async Task<IActionResult> TechRequests()
        {
            var userId = _userManager.GetUserId(User);
            var requests = await _context.ServiceRequests
                .Include(sr => sr.Customer)
                .Where(sr => sr.TechnicianId == userId)
                .ToListAsync();
            return View(requests);
        }

        /// <summary>
        /// Техникът вижда заявките за днес.
        /// </summary>
        [Authorize(Roles = "Tech")]
        public async Task<IActionResult> TodayRequests()
        {
            var userId = _userManager.GetUserId(User);
            var today = DateTime.Today;
            var requests = await _context.ServiceRequests
                .Include(sr => sr.Customer)
                .Where(sr => sr.TechnicianId == userId && sr.VisitDate.HasValue && sr.VisitDate.Value.Date == today)
                .ToListAsync();
            return View(requests);
        }

        /// <summary>
        /// Техникът сменя статуса на заявка.
        /// </summary>
        [Authorize(Roles = "Tech")]
        public async Task<IActionResult> ChangeStatus(int id)
        {
            var userId = _userManager.GetUserId(User);
            var request = await _context.ServiceRequests.FirstOrDefaultAsync(sr => sr.Id == id && sr.TechnicianId == userId);
            if (request == null) return NotFound();
            ViewBag.Statuses = new List<string> { "изчакваща", "очаква посещение", "в прогрес", "приключена" };
            return View(request);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Tech")]
        public async Task<IActionResult> ChangeStatus(int id, string newStatus)
        {
            var userId = _userManager.GetUserId(User);
            var request = await _context.ServiceRequests.FirstOrDefaultAsync(sr => sr.Id == id && sr.TechnicianId == userId);
            if (request == null) return NotFound();
            request.Status = newStatus;
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(TechRequests));
        }

        // ===========================
        //  ADMIN ACTIONS
        // ===========================

        /// <summary>
        /// Администраторът вижда всички заявки, с опция за филтриране по клиент.
        /// </summary>
        [Authorize(Roles = "Administrator")]
        public async Task<IActionResult> AdminRequests(string? customerFilter)
        {
            var query = _context.ServiceRequests
                .Include(sr => sr.Customer)
                .Include(sr => sr.Technician)
                .AsQueryable();

            if (!string.IsNullOrEmpty(customerFilter))
            {
                query = query.Where(sr => sr.CustomerId == customerFilter);
            }

            var customers = await _userManager.GetUsersInRoleAsync("Customer");
            ViewBag.Customers = customers.Select(c => new SelectListItem { Value = c.Id, Text = c.Email }).ToList();
            ViewBag.CustomerFilter = customerFilter;

            return View(await query.ToListAsync());
        }

        /// <summary>
        /// Администраторът зачислява техник и дата на посещение.
        /// </summary>
        [Authorize(Roles = "Administrator")]
        public async Task<IActionResult> Assign(int id)
        {
            var request = await _context.ServiceRequests.FindAsync(id);
            if (request == null) return NotFound();
            var techs = await _userManager.GetUsersInRoleAsync("Tech");
            ViewBag.Technicians = techs.Select(t => new SelectListItem { Value = t.Id, Text = t.Email }).ToList();
            return View(request);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrator")]
        public async Task<IActionResult> Assign(int id, string technicianId, DateTime visitDate)
        {
            var request = await _context.ServiceRequests.FindAsync(id);
            if (request == null) return NotFound();

            if (visitDate.Date < DateTime.Today)
            {
                ModelState.AddModelError("visitDate", "Датата за посещение не може да бъде в миналото.");
                var techs = await _userManager.GetUsersInRoleAsync("Tech");
                ViewBag.Technicians = techs.Select(t => new SelectListItem { Value = t.Id, Text = t.Email }).ToList();
                return View(request);
            }

            request.TechnicianId = technicianId;
            request.VisitDate = visitDate;
            request.Status = "очаква посещение";
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(AdminRequests));
        }

        /// <summary>
        /// Администраторът изтрива всяка заявка без ограничение на статус.
        /// </summary>
        [Authorize(Roles = "Administrator")]
        public async Task<IActionResult> AdminDelete(int id)
        {
            var request = await _context.ServiceRequests
                .Include(sr => sr.Customer)
                .FirstOrDefaultAsync(sr => sr.Id == id);
            if (request == null) return NotFound();
            return View(request);
        }

        [HttpPost, ActionName("AdminDelete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrator")]
        public async Task<IActionResult> AdminDeleteConfirmed(int id)
        {
            var request = await _context.ServiceRequests.FindAsync(id);
            if (request == null) return NotFound();
            _context.ServiceRequests.Remove(request);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(AdminRequests));
        }
    }
}
